import Foundation


public class Tello {
    
    public let port: Int32 = 8889
    public let host = "192.168.10.1"
    public var socket: Socket?
    public let sleepTime:UInt32 = 4
    
    public init() {
        do {
            socket = try createUDPHelper()
            command()
            
        } catch {
            print("createUDPHelper Error")
        }
        
        
    }

     func createUDPHelper(family: Socket.ProtocolFamily = .inet) throws -> Socket {
        
        let socket = try Socket.create(family: family, type: .datagram, proto: .udp)
        
        return socket
    }
    
     func udpHelper(family: Socket.ProtocolFamily) throws {
        
        do {
            let socket = try createUDPHelper()
            try socket.listen(on: Int(port))
            print("try createUDPHelper")
            
        } catch let error {
            
            print("udpHelper Error")
            
            guard let socketError = error as? Socket.Error else {
                
                print("Unexpected error...")
                return
            }
            
            // This error is expected when we're shutting it down...
            if socketError.errorCode == Int32(Socket.SOCKET_ERR_WRITE_FAILED) {
                return
            }
            print("udpHelper Error reported: \(socketError.description)")
        }
    }
    
     func command() {
        
        let addr = Socket.createAddress(for: host, on: port)
        do {
            try socket?.write(from: "command".data(using: .utf8)!, to: addr!)
            
        } catch {
            print("command Error")
        }
    }
    ////
    public func takeOff() {
        
        let addr = Socket.createAddress(for: host, on: port)
        do {


            try socket?.write(from: "takeoff".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)
        } catch {
            print("takeoff Error")
        }
    }
    
    public func land() {
        
        let addr = Socket.createAddress(for: host, on: port)
        do {

            try socket?.write(from: "land".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)

        } catch {
            print("land Error")
        }
    }
    
    public func up(distance: Int) {
        
        let addr = Socket.createAddress(for: host, on: port)
        let dis:String = String(describing:distance)
        do {
            try socket?.write(from: "up \(dis)".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)

        } catch {
            print("up Error")
        }
    }
    
    public func down(distance: Int) {
        
        let addr = Socket.createAddress(for: host, on: port)
        let dis:String = String(describing:distance)

        do {
            try socket?.write(from: "down \(dis)".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)

        } catch {
            print("down Error")
        }
    }
    
    public func forward(distance: Int) {
        
        let addr = Socket.createAddress(for: host, on: port)
        let dis:String = String(describing:distance)

        do {
            try socket?.write(from: "forward \(dis)".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)

        } catch {
            print("forward Error")
        }
    }
    
    public func back(distance: Int) {
        
        let addr = Socket.createAddress(for: host, on: port)
        let dis:String = String(describing:distance)

        do {
            try socket?.write(from: "back \(dis)".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)

        } catch {
            print("back Error")
        }
    }
    
    public func left(distance: Int) {
        
        let addr = Socket.createAddress(for: host, on: port)
        let dis:String = String(describing:distance)
        
        do {
            try socket?.write(from: "left \(dis)".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)
            
        } catch {
            print("left Error")
        }
    }
    
    public func right(distance: Int) {
        
        let addr = Socket.createAddress(for: host, on: port)
        let dis:String = String(describing:distance)
        
        do {
            try socket?.write(from: "right \(dis)".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)
            
        } catch {
            print("right Error")
        }
    }
    
    
    public func rotateClockwise(degree:Int) {
        
        let addr = Socket.createAddress(for: host, on: port)
        let deg:String = String(describing:degree)

        do {
            try socket?.write(from: "cw \(deg)".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)

        } catch {
            print("cw Error")
        }
    }
    
    public func rotateCounterClockwise(degree:Int) {
        
        let addr = Socket.createAddress(for: host, on: port)
        let deg:String = String(describing:degree)

        do {
            try socket?.write(from: "ccw \(deg)".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)

        } catch {
            print("ccw Error")
        }
    }
    
    public func flipLeft() {
        
        let addr = Socket.createAddress(for: host, on: port)
        do {
            try socket?.write(from: "flip l".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)

        } catch {
            print("flipLeft Error")
        }
    }
    
    public func flipRight() {
        
        let addr = Socket.createAddress(for: host, on: port)
        do {
            try socket?.write(from: "flip r".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)
            
        } catch {
            print("flipRight Error")
        }
    }
    
    public func flipForward() {
        
        let addr = Socket.createAddress(for: host, on: port)
        do {
            try socket?.write(from: "flip f".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)
            
        } catch {
            print("flipForward Error")
        }
    }
    
    public func flipBack() {
        
        let addr = Socket.createAddress(for: host, on: port)
        do {
            try socket?.write(from: "flip b".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)
            
        } catch {
            print("flipBack Error")
        }
    }
    
//    public func flipBackLeft() {
//
//        let addr = Socket.createAddress(for: host, on: port)
//        do {
//            try socket?.write(from: "flip bl".data(using: .utf8)!, to: addr!)
//            sleep(sleepTime)
//
//        } catch {
//            print("flipBackLeft Error")
//        }
//    }
//
//    public func flipBackRight() {
//
//        let addr = Socket.createAddress(for: host, on: port)
//        do {
//            try socket?.write(from: "flip rb".data(using: .utf8)!, to: addr!)
//            sleep(sleepTime)
//
//        } catch {
//            print("flipBackRight Error")
//        }
//    }
//
//    public func flipFrontLeft() {
//
//        let addr = Socket.createAddress(for: host, on: port)
//        do {
//            try socket?.write(from: "flip fl".data(using: .utf8)!, to: addr!)
//            sleep(sleepTime)
//
//        } catch {
//            print("flipFrontLeft Error")
//        }
//    }
//
//    public func flipFrontRight() {
//
//        let addr = Socket.createAddress(for: host, on: port)
//        do {
//            try socket?.write(from: "flip fr".data(using: .utf8)!, to: addr!)
//            sleep(sleepTime)
//            
//        } catch {
//            print("flipFrontRight Error")
//        }
//    }
    
    public func setSpeed(speed: Int) {
        
        let addr = Socket.createAddress(for: host, on: port)
        let s:String = String(describing:speed)

        do {
            try socket?.write(from: "speed \(s)".data(using: .utf8)!, to: addr!)
            sleep(sleepTime)
            
        } catch {
            print("speed Error")
        }
    }
    
    public func wait(second: UInt32){
        
        sleep(second)
    }

    
}
